<?php
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);

require_once 'Database.php';
class DAO
{
    public static function listAll()
    {
        $pdo = Database::getInstance()->getPdo();
        $sql = "SELECT * FROM `municipios_brasil_populacao_2022_V5`";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }


    public static function listTenMostPopulousCities()
    {
        $pdo = Database::getInstance()->getPdo();
        $sql = "SELECT Municipio FROM `municipios_brasil_populacao_2022_V5` order by Populacao desc limit 10";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function listTenMostPopulousCitiesOnState($state)
    {
        $pdo = Database::getInstance()->getPdo();
        $sql = "SELECT Municipio FROM `municipios_brasil_populacao_2022_V5` order by Populacao desc limit 10 WHERE Estado = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$state]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    
}
