<?php
include 'raizesEquacaoSegundoGrau.php';

raizesEquacaoSegundoGrau(3,10,1, $raiz1, $raiz2);
echo $raiz1 . "<br>" . $raiz2;
