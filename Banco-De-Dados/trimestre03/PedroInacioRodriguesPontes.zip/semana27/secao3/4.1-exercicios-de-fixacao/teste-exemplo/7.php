<!DOCTYPE html>

<body>
    <?php
    $homepage = file_get_contents("https://www.geeksforgeeks.org/");
    echo $homepage;
    // https :// www . geeksforgeeks . org / php - file_get_contents - function /
    ?>
</body>

</html>
