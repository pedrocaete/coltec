<?php
class User{
    public $cpf;
    public $nome;
    public $email;
    public $telefone;
    public $senha;

}
