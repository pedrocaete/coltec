<?php
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);

class Form
{
    public static function getCpf()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
            $cpf = $_POST['cpf'];
            if (empty($cpf)) {
                echo '<p style="color:red">Preencha todos os campos</p>';
                exit;
            }
            return $cpf;
        }
    }

    public static function getName()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
            $name = $_POST['name'];
            if (empty($name)) {
                echo '<p style="color:red">Preencha todos os campos</p>';
                exit;
            }
            return $name;
        }
    }

    public static function getEmail()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
            $email = $_POST['email'];
            if (empty($email)) {
                echo '<p style="color:red">Preencha todos os campos</p>';
                exit;
            }
            return $email;
        }
    }

    public static function getPhone()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
            $phone = $_POST['phone'];
            if (empty($phone)) {
                echo '<p style="color:red">Preencha todos os campos</p>';
                exit;
            }
            return $phone;
        }
    }

    public static function getPassword()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
            $password = $_POST['password'];
            if (empty($password)) {
                echo '<p style="color:red">Preencha todos os campos</p>';
                exit;
            }
            return $password;
        }
    }
}
