<?php

ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
require_once dirname(__FILE__) . '/../Database/database.php';

class usuarioDAO
{
    public function insert($cpf, $nome, $email, $telefone, $senha)
    {
        $pdo = Database::getInstance()->getPdo();
        $sql = "INSERT INTO usuario VALUES(?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$cpf, $nome, $email, $telefone, $senha]);
        if ($stmt) {
            echo "Usuário Cadastrado com Sucesso";
        } else {
            echo "Erro ao Cadastrar Usuário";
        }
    }

    public function listAll(){
        $pdo = Database::getInstance()->getPdo();
        $sql = "SELECT * FROM usuario";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchColumn();
    }

    private static function fetchColumn($cpf, $column)
    {
        $pdo = Database::getInstance()->getPdo();
        $sql = "SELECT $column FROM usuario WHERE cpf = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$cpf]);
        return $stmt->fetchColumn();
    }

    private static function updateColumn($cpf, $column, $value)
    {
        $pdo = Database::getInstance()->getPdo();
        $sql = "UPDATE usuario SET $column = ? WHERE cpf = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$value, $cpf]);
    }

    // Getters
    public static function getNome($cpf)
    {
        return self::fetchColumn($cpf, 'nome');
    }

    public static function getEmail($cpf)
    {
        return self::fetchColumn($cpf, 'email');
    }

    public static function getTelefone($cpf)
    {
        return self::fetchColumn($cpf, 'telefone');
    }

    public static function getSenha($cpf)
    {
        return self::fetchColumn($cpf, 'senha');
    }

    // Updaters
    public static function updateNome($cpf, $nome)
    {
        self::updateColumn($cpf, 'nome', $nome);
    }

    public static function updateEmail($cpf, $email)
    {
        self::updateColumn($cpf, 'email', $email);
    }

    public static function updateTelefone($cpf, $telefone)
    {
        self::updateColumn($cpf, 'telefone', $telefone);
    }

    public static function updateSenha($cpf, $senha)
    {
        self::updateColumn($cpf, 'senha', $senha);
    }
}
