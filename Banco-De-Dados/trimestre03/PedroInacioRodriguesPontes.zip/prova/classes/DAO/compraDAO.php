<?php

ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
require_once dirname(__FILE__) . '/../Database/database.php';

class estabelecimentoDAO
{
    public function insert($data, $valor, $cpf, $cnpj)
    {
        $pdo = Database::getInstance()->getPdo();
        $sql = "INSERT INTO compra VALUES(?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$data, $valor, $cpf, $cnpj]);
        if ($stmt) {
            echo "Usuário Cadastrado com Sucesso";
        } else {
            echo "Erro ao Cadastrar Usuário";
        }
    }

    public function listAllByCnpj($cnpj){
        $pdo = Database::getInstance()->getPdo();
        $sql = "SELECT * FROM compra WHERE cnpj = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$cnpj]);
        return $stmt->fetchColumn();
    }

    public function listAllByCpf($cpf){
        $pdo = Database::getInstance()->getPdo();
        $sql = "SELECT * FROM compra WHERE cpf = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$cpf]);
        return $stmt->fetchColumn();
    }

    public function listAll(){
        $pdo = Database::getInstance()->getPdo();
        $sql = "SELECT * FROM compra";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchColumn();
    }
    
    private static function fetchColumn($id, $column)
    {
        $pdo = Database::getInstance()->getPdo();
        $sql = "SELECT $column FROM compra WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$id]);
        return $stmt->fetchColumn();
    }

    private static function updateColumn($id, $column, $value)
    {
        $pdo = Database::getInstance()->getPdo();
        $sql = "UPDATE compra SET $column = ? WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$value, $id]);
    }

    // Getters
    public static function getData($id)
    {
        return self::fetchColumn($id, 'data');
    }

    public static function getValor($id)
    {
        return self::fetchColumn($id, 'valor');
    }

    public static function getCpf($id)
    {
        return self::fetchColumn($id, 'cpf');
    }

    public static function getCnpj($id)
    {
        return self::fetchColumn($id, 'cnpj');
    }

    // Updaters
    public static function updateData($id, $data)
    {
        self::updateColumn($id, 'data', $data);
    }

    public static function updateValor($id, $valor)
    {
        self::updateColumn($id, 'valor', $valor);
    }

    public static function updateCpf($id, $cpf)
    {
        self::updateColumn($id, 'cpf', $cpf);
    }

    public static function updateCnpj($id, $newCnpj)
    {
        self::updateColumn($id, 'cnpj', $newCnpj);
    }
}
