<!DOCTYPE html>
<html lang="pt">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cadastro Usuário</title>
    <link href="../../css/style.css" rel="stylesheet">
</head>

<body>
    <div class='mainText'>
        <form method="post">
            <h1>Cadastro Usuário</h1>
            <label for="name">Usuário:</label> <br>
            <input type="text" name="name" value=""><br> <br>

            <label for="cpf">CPF:</label> <br>
            <input type="text" name="cpf" value=""><br> <br>

            <label for="email">Email: </label> <br>
            <input type="text" name="email" value=""> <br> <br>

            <label for="phone">Telefone (DDD 31 já incluído): </label> <br>
            <input type="text" name="phone" value=""> <br> <br>

            <label for="password">Senha:</label> <br>
            <input type="password" name="password" value=""> <br> <br>

            <input type="submit" name="submit" value="Cadastrar"> <br><br>
        </form>
    </div>
    <a class='upperText' href='../login/login.php'>Login</a>
</body>

</html>

<?php
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);

//require_once "register.html";
//require_once "../../classes/user/UserRegister.php";
//
//if (isset($_POST['submit'])) {
//    $user = new UserRegister();
//    if ($user->register()) {
//        header('Location: ../user_area/info.php');
//    }
//}
