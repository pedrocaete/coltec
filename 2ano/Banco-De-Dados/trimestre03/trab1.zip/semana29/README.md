# Como usar

- Troque a variável $host em classes/Databse.php para o endereço do seu servidor web.

- Crie um banco de dados mySql com o código em databse/sistema.sql. Caso altere o nome do banco de dados, altere a variável $db. Altere as variáveis $user e $pass para seu respectivo usuário e senha para o database criado. Essas alterações são feitas em classes/Database.php.
